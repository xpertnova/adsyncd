class UserAdministration:
    _users = []
    def __init__(self):
        pass
    def syncUsers(self):
        pass
    def getUsernameList(self):
        pass
    def userExists(self, username):
        pass